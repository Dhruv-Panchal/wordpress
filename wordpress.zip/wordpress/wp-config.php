<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'Test');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'PlEGcqm4u)vHj:LG%WrOvsRG883HDgt.lIUAP7b.#^ujL;Z6DpPF&~?!s%S+dHJe');
define('SECURE_AUTH_KEY',  'wT][Y%-pyog5;=B5Psq?K.9R(mzh3!*ZK1BbKz+Qx4^43//k{@$vq(_=U!w)Msc,');
define('LOGGED_IN_KEY',    '/7HJeJethO[Mz|lf^=EP<,Cx.^W9ZGE6pYUHigR1+`[ar*U6GjpDF*RyrL rY[Vu');
define('NONCE_KEY',        'jt_M,9$2z34})dNV2:Rx xin_q:c+_Bz8!F>$E4[W+|gfva7q7Wi];&PVvD`g`tA');
define('AUTH_SALT',        'HG7xNuC`a#;dI^31L/30:]ZnJ/.%Q>^]@)7HAc_*8s-9y]E-:&i<rG$/(-cpFNJw');
define('SECURE_AUTH_SALT', ',*:+dP,Cz,`m3hz3 Xd)`iWlF+4m=U5 TLkybxK=x[cq_mtHR/z|kfzhTQhxhNfW');
define('LOGGED_IN_SALT',   'tUIMm|O5y2H,o(<w2+ ZjM}B(apu4MX:#8  7wJoz_$t0e<v Z!gx,8.vPDgVPOB');
define('NONCE_SALT',       'P>%Yuw;auw;4g^k:+jO2:`HNk)_kQ$s`QCcb!t_y_R?s #}*S&YuZC#X%FQJ-TXc');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
